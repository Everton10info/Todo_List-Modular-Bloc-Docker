import 'package:flutter_modular/flutter_modular.dart';

import '../todo/repositories/todo_repository.dart';
import 'pages/splash_page.dart';

class SplashModule extends Module {
  @override
  List<Bind> get binds => [
    Bind((i) => TodoRepository(i())),
      ];

  @override
  List<ModularRoute> get routes => [
        ChildRoute('/', child: (context, args) =>  const SplashPage()),
      ];
}
