import 'package:flutter/material.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:modular_bloc_docker/Http/app_http_client.dart';
import 'package:modular_bloc_docker/todo/repositories/todo_repository.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    _loadPage();

    super.initState();
  }

  _loadPage() {
    Future.delayed(const Duration(seconds: 5))
        .then((value) => Modular.to.navigate('/todo'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          alignment: Alignment.center,
          width: 500,
          height: 500,
          color: Colors.yellowAccent,
          child: const Text(
            'Docker, Modular and Bloc',
            style: TextStyle(fontSize: 25),
          ),
        ),
      ),
    );
  }
}
